jQuery(document).ready(function($) {    
	jQuery('.meanthemes-reset input').click(function() {
		var alertme = jQuery(this).attr("rel");
		alert(alertme);
	});	
});



