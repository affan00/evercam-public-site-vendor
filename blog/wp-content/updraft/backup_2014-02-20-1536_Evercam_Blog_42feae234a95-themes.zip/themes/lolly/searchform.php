<form role="search" method="get" class="searchform" action="<?php echo home_url( '/' ); ?>">
    <div>
        <input type="text" value="" name="s" class="s" placeholder="<?php _e("Type and hit enter","meanthemes"); ?>" />
        	<input type="submit" class="searchsubmit" value="<?php _e("Search","meanthemes"); ?>" />
    </div>
</form>