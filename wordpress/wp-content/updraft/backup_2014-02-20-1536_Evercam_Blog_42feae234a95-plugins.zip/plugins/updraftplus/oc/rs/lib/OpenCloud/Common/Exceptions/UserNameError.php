<?php

namespace OpenCloud\Common\Exceptions;

class UserNameError extends \Exception {}
