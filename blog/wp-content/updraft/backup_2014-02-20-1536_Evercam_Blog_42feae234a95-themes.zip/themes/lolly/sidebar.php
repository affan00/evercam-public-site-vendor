<?php $content_options = get_option ( 'meanthemes_theme_content_options_lolly' ); ?>
<?php $general_options = get_option ( 'meanthemes_theme_general_options_lolly' ); ?>
<?php if ( ( is_single() ) || ( is_archive() ) || ( !is_page() ) ) { ?>
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
	<?php endif; ?>
<?php } ?>
<?php if ( (is_page()) && (!is_page_template('template-contact.php')) ) { ?>
	<?php if( (isset($general_options[ 'hide_page_menu' ])) && ($general_options[ 'hide_page_menu' ])) {
	// no nothing
	} else { ?>	
		<h5><?php echo sanitize_text_field( $content_options['navigation'] );?></h5>
		<nav class="page-navigation">
			<ul>
			    <?php wp_list_pages( array('title_li'=>'','include'=>get_post_top_ancestor_id()) ); ?>
			    <?php wp_list_pages( array('title_li'=>'','depth'=>1,'child_of'=>get_post_top_ancestor_id()) ); ?>
			</ul>
		</nav>
	<?php } ?>	
	<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Page Widget Area')) : ?>
	<?php endif; ?>
<?php } ?>
<?php if ( is_page_template('template-contact.php') ) { ?>	
	<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Contact Widget Area')) : ?>
	<?php endif; ?>
<?php } ?>

