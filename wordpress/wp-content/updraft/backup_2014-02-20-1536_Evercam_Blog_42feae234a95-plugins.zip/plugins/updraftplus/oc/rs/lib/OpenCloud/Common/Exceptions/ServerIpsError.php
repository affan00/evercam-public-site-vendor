<?php

namespace OpenCloud\Common\Exceptions;

class ServerIpsError extends \Exception {}
