== Description ==
tdSimple is super clean, very simple and elegant WordPress theme. It's also responsive.
 
== License: ==
This theme uses a starter theme "Underscores"
License:  GNU GENERAL PUBLIC LICENSE
License URI: licensing/license.txt

There are however some parts of this Theme which are not
GPL but they are GPL-Compatible.

See headers of JS files for further details.

Foundation Framework (including images and icons).
http://foundation.zurb.com/
License: MIT

Image Credit (screenshot):
photo by Smolskiy Eugene.

== Theme Documentation: ==
 Please visit: http://tasko.us/support/topic/tdsimple-theme-documentation/

==  Theme Support: ==
 If you have any questions, please post them here: 
 http://tasko.us/support/discussion/tdsimple-theme/

== Changelog ==
 - v1.0.5 - theme customizer features and mobile issues fixed.
 - v1.0.4 - added feature that makes tables responsive.
 - v1.0.1 - added feature that makes videos responsive.
 - v1.0 - Initial release.

 
 