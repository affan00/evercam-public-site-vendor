<?php get_header(); ?>
<div class="wrapper full-wrap page-wrap pnf">
<div class="wrapper full-wrap">
	<div class="content">
	    <article id="post-<?php the_ID(); ?>">
	    			    <h1><?php _e( "We're awfully sorry! We cannot find that page", "meanthemes" ); ?></h1>
	    		<div class="post-content">
	        		<p><?php _e( "Sorry, we can't find that page, please try clicking on the navigation above.", "meanthemes" ); ?></p>
		        </div>
	    </article>
	</div>    
</div>	   
</div>	   
<?php get_footer(); ?>
