<?php

namespace OpenCloud\Common\Exceptions;

class IdRequiredError extends \Exception {}
