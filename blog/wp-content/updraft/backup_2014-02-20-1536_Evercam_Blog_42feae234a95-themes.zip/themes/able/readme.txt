== Changelog ==

= 1.2 May 16 2013 =
* Updated license to GPLv2 or later and added canonical resource link. 
* Fixed a bug with the syntax highlighter table-layout.
* Made theme forward compatible with 3.6.
* Improved styles for Recent Comments widget.

= 1.1.1 Feb 18 2013 =
* Updated screenshot.png for HiDPI.
* Made sure that tables with tons of content don't overflow into sidebars.

= 1.1 Jan 29 2013 =
* Corrected text domain in footer.
* Added check for the existence of the class/method `Jetpack_User_Agent_Info` and `is_ipad before checking` if an iPad is being used.
* Ensured that View full size text in the Carousel meta area doesn't have a double-icon next to it.
* Made sure that each comment is properly cleared.

= 1.0 Jan 3 2013 =
* Initial release.