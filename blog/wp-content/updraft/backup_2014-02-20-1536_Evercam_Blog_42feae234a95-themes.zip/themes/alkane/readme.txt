=== Alkane – Free WordPress Theme ===

Alkane is a simple, customizable and clean theme for WordPress. It uses superfish menu effects, built-in pagination for post pages and an elegant layout. Add your own personal flair by uploading a custom header or background image. The customization options include theme settings page, custom background, custom header.

=== Designed by WPAlkane.com ===

http://wpalkane.com/alkane/

=== Support ===

http://wpalkane.com/