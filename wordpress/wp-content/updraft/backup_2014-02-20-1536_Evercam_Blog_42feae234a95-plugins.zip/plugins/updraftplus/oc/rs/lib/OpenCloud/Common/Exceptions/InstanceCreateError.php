<?php

namespace OpenCloud\Common\Exceptions;

class InstanceCreateError extends \Exception {}
