<?php

namespace OpenCloud\Common\Exceptions;

class CdnError extends \Exception {}
