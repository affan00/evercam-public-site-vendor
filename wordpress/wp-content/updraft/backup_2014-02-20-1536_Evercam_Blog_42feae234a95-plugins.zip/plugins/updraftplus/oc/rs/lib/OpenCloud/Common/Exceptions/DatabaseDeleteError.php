<?php

namespace OpenCloud\Common\Exceptions;

class DatabaseDeleteError extends \Exception {}
