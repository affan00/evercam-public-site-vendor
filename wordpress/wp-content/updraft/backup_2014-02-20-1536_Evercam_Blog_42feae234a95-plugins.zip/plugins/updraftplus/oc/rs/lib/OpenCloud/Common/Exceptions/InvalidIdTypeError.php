<?php

namespace OpenCloud\Common\Exceptions;

class InvalidIdTypeError extends \Exception {}
